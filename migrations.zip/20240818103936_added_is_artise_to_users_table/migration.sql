-- AlterTable
ALTER TABLE `users` ADD COLUMN `is_artise` BOOLEAN NOT NULL DEFAULT false;
