/*
  Warnings:

  - Added the required column `id` to the `TrackLike` table without a default value. This is not possible if the table is not empty.

*/
-- DropIndex
DROP INDEX `TrackLike_track_id_user_id_key` ON `tracklike`;

-- AlterTable
ALTER TABLE `tracklike` ADD COLUMN `id` INTEGER NOT NULL AUTO_INCREMENT,
    ADD PRIMARY KEY (`id`);
