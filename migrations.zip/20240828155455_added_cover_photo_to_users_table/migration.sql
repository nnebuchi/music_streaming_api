-- AlterTable
ALTER TABLE `users` ADD COLUMN `cover_photo` TEXT NULL;
