-- AlterTable
ALTER TABLE `users` ADD COLUMN `slug` VARCHAR(191) NULL;
