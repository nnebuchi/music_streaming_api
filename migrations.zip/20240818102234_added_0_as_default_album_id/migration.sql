-- AlterTable
ALTER TABLE `tracks` MODIFY `album_id` INTEGER NOT NULL DEFAULT 0;
