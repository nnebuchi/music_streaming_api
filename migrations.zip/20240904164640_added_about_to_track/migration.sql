-- AlterTable
ALTER TABLE `tracks` ADD COLUMN `about` TEXT NULL,
    MODIFY `duration` VARCHAR(191) NULL;
