-- AlterTable
ALTER TABLE `users` ADD COLUMN `profile_photo` TEXT NULL;
